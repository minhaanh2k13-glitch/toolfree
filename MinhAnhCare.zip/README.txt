MINH ANH CARE
================

Bản PC quản lý tài khoản/Chrome Profile với proxy tùy chọn.

Chạy:
1. Cài Python 3.x trên Windows.
2. Mở thư mục này.
3. Chạy: python main.py

Hoặc double-click run.bat.

Chức năng:
- Quản lý tên tài khoản, email, proxy, Chrome Profile, ghi chú.
- Định dạng Proxy hỗ trợ cả 2 dạng:
  + ip:port
  + ip:port:user:pass (Tự tạo Extension để đăng nhập tự động)
- Mỗi tài khoản có thư mục Chrome Profile riêng biệt trong /profiles.
- Mở Facebook bằng Chrome Profile đã chọn.
- Dữ liệu lưu tại data/accounts.json.
