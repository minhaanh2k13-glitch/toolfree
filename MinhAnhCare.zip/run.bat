@echo off
title Minh Anh Care
python main.py
if errorlevel 1 pause
