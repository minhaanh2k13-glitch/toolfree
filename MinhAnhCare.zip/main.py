import json
import os
import shutil
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(APP_DIR, "data")
PROFILE_DIR = os.path.join(APP_DIR, "profiles")
EXT_DIR = os.path.join(APP_DIR, "extensions")
DATA_FILE = os.path.join(DATA_DIR, "accounts.json")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(PROFILE_DIR, exist_ok=True)
os.makedirs(EXT_DIR, exist_ok=True)

def load_accounts():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def save_accounts():
    data = []
    for item in tree.get_children():
        v = tree.item(item, "values")
        data.append({
            "name": v[0],
            "email": v[1],
            "proxy": v[2],
            "profile": v[3],
            "note": v[4]
        })
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def chrome_path():
    candidates = [
        os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return None

def create_proxy_extension(proxy_str, profile_name):
    """Tự động tạo Chrome Extension tạm để authenticate Proxy có dạng ip:port:user:pass"""
    parts = proxy_str.split(":")
    if len(parts) != 4:
        return None

    host, port, user, password = parts[0], parts[1], parts[2], parts[3]
    ext_path = os.path.join(EXT_DIR, f"proxy_{profile_name}")
    os.makedirs(ext_path, exist_ok=True)

    manifest_json = """{
        "version": "1.0.0",
        "manifest_version": 2,
        "name": "Proxy Auto Auth",
        "permissions": [
            "proxy",
            "tabs",
            "unlimitedStorage",
            "storage",
            "<all_urls>",
            "webRequest",
            "webRequestBlocking"
        ],
        "background": {
            "scripts": ["background.js"]
        },
        "minimum_chrome_version":"22.0.0"
    }"""

    background_js = f"""var config = {{
        mode: "fixed_servers",
        rules: {{
          singleProxy: {{
            scheme: "http",
            host: "{host}",
            port: parseInt({port})
          }},
          bypassList: ["localhost"]
        }}
      }};

    chrome.proxy.settings.set({{value: config, scope: "regular"}}, function() {{}});

    function callbackFn(details) {{
        return {{
            authCredentials: {{
                username: "{user}",
                password: "{password}"
            }}
        }};
    }}

    chrome.webRequest.onAuthRequired.addListener(
            callbackFn,
            {{urls: ["<all_urls>"]}},
            ['blocking']
    );"""

    with open(os.path.join(ext_path, "manifest.json"), "w", encoding="utf-8") as f:
        f.write(manifest_json)
    with open(os.path.join(ext_path, "background.js"), "w", encoding="utf-8") as f:
        f.write(background_js)

    return ext_path

def add_account():
    name = name_var.get().strip()
    email = email_var.get().strip()
    proxy = proxy_var.get().strip()
    profile = profile_var.get().strip()
    note = note_var.get().strip()
    if not name:
        messagebox.showwarning("Thiếu dữ liệu", "Nhập tên tài khoản/Profile trước.")
        return
    if not profile:
        profile = name.replace(" ", "_")
    tree.insert("", "end", values=(name, email, proxy, profile, note))
    clear_form()
    save_accounts()

def selected_item():
    sel = tree.selection()
    return sel[0] if sel else None

def edit_account():
    item = selected_item()
    if not item:
        messagebox.showinfo("Chọn tài khoản", "Hãy chọn một dòng trước.")
        return
    vals = (name_var.get().strip(), email_var.get().strip(),
            proxy_var.get().strip(), profile_var.get().strip(),
            note_var.get().strip())
    if not vals[0]:
        messagebox.showwarning("Thiếu dữ liệu", "Tên tài khoản không được trống.")
        return
    tree.item(item, values=vals)
    clear_form()
    save_accounts()

def delete_account():
    item = selected_item()
    if not item:
        return
    tree.delete(item)
    save_accounts()
    clear_form()

def clear_form():
    for v in (name_var, email_var, proxy_var, profile_var, note_var):
        v.set("")
    if tree.selection():
        tree.selection_remove(tree.selection())

def fill_form(event=None):
    item = selected_item()
    if not item:
        return
    vals = tree.item(item, "values")
    name_var.set(vals[0]); email_var.set(vals[1]); proxy_var.set(vals[2])
    profile_var.set(vals[3]); note_var.set(vals[4])

def open_chrome():
    item = selected_item()
    if not item:
        messagebox.showinfo("Chọn tài khoản", "Hãy chọn một dòng trước.")
        return
    vals = tree.item(item, "values")
    profile_name = vals[3].strip()
    proxy = vals[2].strip()

    chrome = chrome_path()
    if not chrome:
        messagebox.showerror("Không tìm thấy Chrome",
                             "Không tìm thấy Google Chrome. Hãy cài Chrome hoặc sửa đường dẫn trong code.")
        return

    user_data = os.path.abspath(os.path.join(PROFILE_DIR, profile_name))
    cmd = [chrome, f"--user-data-dir={user_data}"]

    if proxy:
        parts = proxy.split(":")
        # Nếu Proxy có User:Pass (4 phần ip:port:user:pass)
        if len(parts) == 4:
            ext_path = create_proxy_extension(proxy, profile_name)
            if ext_path:
                cmd.append(f"--load-extension={ext_path}")
        # Nếu Proxy thường (ip:port)
        else:
            cmd.append(f"--proxy-server={proxy}")

    cmd.append("https://www.facebook.com/")
    try:
        subprocess.Popen(cmd)
    except Exception as e:
        messagebox.showerror("Lỗi", str(e))

def load_into_tree():
    for a in load_accounts():
        tree.insert("", "end", values=(
            a.get("name",""), a.get("email",""), a.get("proxy",""),
            a.get("profile",""), a.get("note","")
        ))

root = tk.Tk()
root.title("Minh Anh Care")
root.geometry("1050x600")
root.minsize(900, 500)

style = ttk.Style(root)
try:
    style.theme_use("vista")
except Exception:
    pass

top = ttk.Frame(root, padding=12)
top.pack(fill="x")

name_var = tk.StringVar()
email_var = tk.StringVar()
proxy_var = tk.StringVar()
profile_var = tk.StringVar()
note_var = tk.StringVar()

fields = [
    ("Tên tài khoản", name_var),
    ("Email", email_var),
    ("Proxy (ip:port hoặc ip:port:user:pass)", proxy_var),
    ("Chrome Profile", profile_var),
    ("Ghi chú", note_var),
]
for i, (label, var) in enumerate(fields):
    ttk.Label(top, text=label).grid(row=i//2, column=(i%2)*2, sticky="w", padx=5, pady=5)
    ttk.Entry(top, textvariable=var, width=42).grid(
        row=i//2, column=(i%2)*2+1, sticky="ew", padx=5, pady=5
    )
top.columnconfigure(1, weight=1)
top.columnconfigure(3, weight=1)

buttons = ttk.Frame(root, padding=(12, 0, 12, 10))
buttons.pack(fill="x")
ttk.Button(buttons, text="Thêm", command=add_account).pack(side="left", padx=4)
ttk.Button(buttons, text="Sửa", command=edit_account).pack(side="left", padx=4)
ttk.Button(buttons, text="Xóa", command=delete_account).pack(side="left", padx=4)
ttk.Button(buttons, text="Xóa form", command=clear_form).pack(side="left", padx=4)
ttk.Button(buttons, text="▶ Mở Chrome Profile", command=open_chrome).pack(side="right", padx=4)

frame = ttk.Frame(root, padding=12)
frame.pack(fill="both", expand=True)

columns = ("name", "email", "proxy", "profile", "note")
tree = ttk.Treeview(frame, columns=columns, show="headings")
heads = {
    "name": "Tên tài khoản", "email": "Email", "proxy": "Proxy",
    "profile": "Chrome Profile", "note": "Ghi chú"
}
widths = {"name":180, "email":230, "proxy":180, "profile":180, "note":180}
for c in columns:
    tree.heading(c, text=heads[c])
    tree.column(c, width=widths[c], anchor="w")

ys = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
xs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
tree.grid(row=0, column=0, sticky="nsew")
ys.grid(row=0, column=1, sticky="ns")
xs.grid(row=1, column=0, sticky="ew")
frame.rowconfigure(0, weight=1)
frame.columnconfigure(0, weight=1)
tree.bind("<<TreeviewSelect>>", fill_form)

status = ttk.Label(root, text="Hỗ trợ Proxy IP:PORT hoặc IP:PORT:USER:PASS (bỏ trống = chạy mạng thường)", padding=8)
status.pack(fill="x")

load_into_tree()
root.mainloop()
